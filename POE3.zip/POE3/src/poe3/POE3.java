/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe3;

import javax.swing.*;
import java.util.ArrayList;

public class POE3 {

    private static ArrayList<Task> tasks = new ArrayList<>();

    public static void main(String[] args) {
        User user = register();
        if (user != null) {
            boolean loggedIn = login(user);
            if (loggedIn) {
                System.out.println("Login successful. Welcome to EasyKanban");
                int choice;
                do {
                    choice = displayMenuAndGetChoice();
                    switch (choice) {
                        case 1:
                            addTask(user);
                            break;
                        case 2:
                            showReport();
                            break;
                        case 3:
                            showTasksWithStatusDone();
                            break;
                        case 4:
                            showLongestDurationTask();
                            break;
                        case 5:
                            searchTaskByName();
                            break;
                        case 6:
                            searchTasksByDeveloper();
                            break;
                        case 7:
                            deleteTaskByName();
                            break;
                        case 8:
                            System.out.println("Exiting EasyKanban. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please enter a valid option.");
                    }
                } while (choice != 8);
            } else {
                System.out.println("Login failed. Exiting.");
            }
        }
    }

    private static User register() {
        while (true) {
            String username = JOptionPane.showInputDialog(null, "Enter username:");
            if (username == null) return null; // Stop program if cancel is pressed

            String password = JOptionPane.showInputDialog(null, "Enter password:");
            if (password == null) return null; // Stop program if cancel is pressed

            String name = JOptionPane.showInputDialog(null, "Enter first name:");
            if (name == null) return null; // Stop program if cancel is pressed

            String surname = JOptionPane.showInputDialog(null, "Enter last name:");
            if (surname == null) return null; // Stop program if cancel is pressed

            return new User(username, password, name, surname);
        }
    }

    private static boolean login(User user) {
        while (true) {
            String username = JOptionPane.showInputDialog(null, "Enter username to login:");
            if (username == null) return false; // Stop program if cancel is pressed

            String password = JOptionPane.showInputDialog(null, "Enter password to login:");
            if (password == null) return false; // Stop program if cancel is pressed

            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
            }
        }
    }

    public static int displayMenuAndGetChoice() {
        String menu = "Select an option:\n1. Add Task\n2. Show Report\n3. Show Tasks with Status 'Done'\n4. Show Task with Longest Duration\n5. Search Task by Name\n6. Search Tasks by Developer\n7. Delete Task by Name\n8. Quit";
        String choiceStr = JOptionPane.showInputDialog(null, menu);
        if (choiceStr != null) {
            try {
                return Integer.parseInt(choiceStr);
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }

    public static void addTask(User user) {
        String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
        if (taskName == null) return; // Stop program if cancel is pressed

        String taskDescription = JOptionPane.showInputDialog(null, "Enter task description (max 50 characters):");
        if (taskDescription == null) return; // Stop program if cancel is pressed

        if (taskDescription.length() > 50) {
            JOptionPane.showMessageDialog(null, "Please enter a task description less than 50 characters long.");
            return;
        }

        int taskDuration;
        try {
            taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration (in hours):"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input for task duration.");
            return;
        }

        Task task = new Task(taskName, taskDescription, user.getName(), user.getSurname(), taskDuration);

        String[] statuses = {"To Do", "Doing", "Done"};
        String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status",
                JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

        if (taskStatus != null) {
            task.setTaskStatus(taskStatus);
            tasks.add(task);
            JOptionPane.showMessageDialog(null, "Task successfully captured:\n" + task);
        } else {
            JOptionPane.showMessageDialog(null, "Task status selection cancelled.");
        }
    }

    public static void showReport() {
        StringBuilder report = new StringBuilder();
        for (Task task : tasks) {
            report.append(task).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, report.length() > 0 ? report.toString() : "No tasks captured yet.");
    }

    public static void showTasksWithStatusDone() {
        StringBuilder report = new StringBuilder();
        for (Task task : tasks) {
            if ("Done".equalsIgnoreCase(task.getTaskStatus())) {
                report.append("Developer: ").append(task.getDeveloperFirstName()).append(" ").append(task.getDeveloperLastName())
                        .append(", Task Name: ").append(task.getTaskName())
                        .append(", Task Duration: ").append(task.getTaskDuration()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.length() > 0 ? report.toString() : "No tasks with status 'Done' found.");
    }

    public static void showLongestDurationTask() {
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks captured yet.");
            return;
        }
        Task longestTask = tasks.get(0);
        for (Task task : tasks) {
            if (task.getTaskDuration() > longestTask.getTaskDuration()) {
                longestTask = task;
            }
        }
        JOptionPane.showMessageDialog(null, "Developer: " + longestTask.getDeveloperFirstName() + " " + longestTask.getDeveloperLastName() +
                "\nDuration: " + longestTask.getTaskDuration());
    }

    public static void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the task name to search:");
        if (taskName == null) return; // Stop program if cancel is pressed

        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + task.getTaskName() + "\nTask Status: " + task.getTaskStatus());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    public static void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog(null, "Enter the developer's first name:");
        if (developerName == null) return; // Stop program if cancel is pressed

        StringBuilder report = new StringBuilder();
        for (Task task : tasks) {
            if (task.getDeveloperFirstName().equalsIgnoreCase(developerName)) {
                report.append("Task Name: ").append(task.getTaskName()).append(", Task Status: ").append(task.getTaskStatus()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, report.length() > 0 ? report.toString() : "No tasks found for developer: " + developerName);
    }

    public static void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the task name to delete:");
        if (taskName == null) return; // Stop program if cancel is pressed

        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                tasks.remove(task);
                JOptionPane.showMessageDialog(null, "Task deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }
    
    static class User {
        private String username;
        private String password;
        private String name;
        private String surname;

        public User(String username, String password, String name, String surname) {
            this.username = username;
            this.password = password;
            this.name = name;
            this.surname = surname;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public String getName() {
            return name;
        }

        public String getSurname() {
            return surname;
        }
    }

    static class Task {
        private static int taskCounter = 0;
        private String taskName;
        private int taskNumber;
        private String taskDescription;
        private String developerFirstName;
        private String developerLastName;
        private int taskDuration;
        private String taskID;
        private String taskStatus;

        public Task(String taskName, String taskDescription, String developerFirstName, String developerLastName, int taskDuration) {
            this.taskName = taskName;
            this.taskDescription = taskDescription;
            this.developerFirstName = developerFirstName;
            this.developerLastName = developerLastName;
            this.taskDuration = taskDuration;
            this.taskNumber = ++taskCounter;
            generateTaskID();
        }

        private void generateTaskID() {
            String initials = taskName.substring(0, 2).toUpperCase();
            String lastNameInitials = developerLastName.substring(developerLastName.length() - 3).toUpperCase();
            taskID = initials + ":" + taskNumber + ":" + lastNameInitials;
        }

        public String getTaskID() {
            return taskID;
        }

        public void setTaskStatus(String status) {
            this.taskStatus = status;
        }

        public String getTaskStatus() {
            return taskStatus;
        }

        public String getDeveloperFirstName() {
            return developerFirstName;
        }

        public String getDeveloperLastName() {
            return developerLastName;
        }

        public String getTaskName() {
            return taskName;
        }

        public int getTaskDuration() {
            return taskDuration;
        }

        public String toString() {
            return "Task Name: " + taskName + "\nTask ID: " + taskID + "\nDescription: " + taskDescription + "\nDeveloper: " + developerFirstName + " " + developerLastName + "\nDuration: " + taskDuration + " hours\nStatus: " + taskStatus;
        }
    }
}
